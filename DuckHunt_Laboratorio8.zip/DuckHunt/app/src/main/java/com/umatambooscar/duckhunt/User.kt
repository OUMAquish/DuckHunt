package com.umatambooscar.duckhunt
data class User (var nick:String, var ducks:Int){
    constructor():this("",0)
}