package com.umatambooscar.duckhunt

const val EXTRA_NICK = "nickname"
const val EXTRA_ID = "id"
